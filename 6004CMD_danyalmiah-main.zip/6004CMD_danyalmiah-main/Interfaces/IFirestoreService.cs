using RecipeVault.Models;

namespace RecipeVault.Interfaces
{
    /// <summary>
    /// Contract for Firestore cloud database (REST API).
    /// Provides cloud CRUD for MealPlanEntries and ShoppingItems.
    /// Endpoint coverage: Create, Read (list + single), Update, Delete
    /// </summary>
    public interface IFirestoreService
    {
        // ── Meal Plan ──────────────────────────────────────────────────
        Task<List<MealPlanEntry>> GetMealPlanAsync(string userId);
        Task<string> AddMealPlanEntryAsync(MealPlanEntry entry, string idToken);
        Task UpdateMealPlanEntryAsync(MealPlanEntry entry, string idToken);
        Task DeleteMealPlanEntryAsync(string firestoreDocId, string userId, string idToken);

        // ── Shopping List ─────────────────────────────────────────────
        Task<List<ShoppingItem>> GetShoppingItemsAsync(string userId);
        Task<string> AddShoppingItemAsync(ShoppingItem item, string idToken);
        Task UpdateShoppingItemAsync(ShoppingItem item, string idToken);
        Task DeleteShoppingItemAsync(string firestoreDocId, string userId, string idToken);
    }
}
