using RecipeVault.Models;

namespace RecipeVault.Interfaces
{
    /// <summary>
    /// Contract for Firebase Authentication (REST API).
    /// Handles sign-up, sign-in and session management.
    /// Design pattern: Interface Segregation (ISP), Dependency Inversion (DIP)
    /// </summary>
    public interface IAuthService
    {
        UserProfile? CurrentUser { get; }
        bool IsLoggedIn { get; }

        Task<(bool Success, string Message)> RegisterAsync(string email, string password, string displayName);
        Task<(bool Success, string Message)> LoginAsync(string email, string password);
        Task LogoutAsync();
        Task<bool> RefreshTokenAsync();
    }
}
