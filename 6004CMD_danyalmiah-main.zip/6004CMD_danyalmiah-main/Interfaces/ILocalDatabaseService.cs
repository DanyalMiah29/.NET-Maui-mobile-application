using RecipeVault.Models;

namespace RecipeVault.Interfaces
{
    /// <summary>
    /// Contract for the local SQLite database.
    /// Full CRUD for Recipes, MealPlanEntries and ShoppingItems.
    /// Design pattern: Repository Pattern
    /// </summary>
    public interface ILocalDatabaseService
    {
        // ── Initialisation ───────────────────────────────────────────
        Task InitAsync();

        // ── Recipes ──────────────────────────────────────────────────
        Task<List<Recipe>> GetAllRecipesAsync();
        Task<List<Recipe>> GetFavoriteRecipesAsync();
        Task<Recipe?> GetRecipeByMealDbIdAsync(string mealDbId);
        Task<int> SaveRecipeAsync(Recipe recipe);
        Task<int> DeleteRecipeAsync(Recipe recipe);
        Task<bool> IsRecipeFavoriteAsync(string mealDbId);
        Task ToggleFavoriteAsync(string mealDbId);

        // ── Meal Plan ────────────────────────────────────────────────
        Task<List<MealPlanEntry>> GetMealPlanEntriesAsync(string userId);
        Task<int> SaveMealPlanEntryAsync(MealPlanEntry entry);
        Task<int> DeleteMealPlanEntryAsync(MealPlanEntry entry);

        // ── Shopping List ────────────────────────────────────────────
        Task<List<ShoppingItem>> GetShoppingItemsAsync(string userId);
        Task<int> SaveShoppingItemAsync(ShoppingItem item);
        Task<int> DeleteShoppingItemAsync(ShoppingItem item);
        Task<int> UpdateShoppingItemAsync(ShoppingItem item);
    }
}
