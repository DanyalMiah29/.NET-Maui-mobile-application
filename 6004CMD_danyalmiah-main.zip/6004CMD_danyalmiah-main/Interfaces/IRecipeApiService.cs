using RecipeVault.Models;

namespace RecipeVault.Interfaces
{
    /// <summary>
    /// Contract for TheMealDB external recipe API.
    /// Endpoint 1: Search by name
    /// Endpoint 2: Lookup by ID
    /// Endpoint 3: List categories
    /// Endpoint 4: Filter by category
    /// </summary>
    public interface IRecipeApiService
    {
        Task<List<Recipe>> SearchRecipesAsync(string query);
        Task<Recipe?> GetRecipeByIdAsync(string mealDbId);
        Task<List<MealDbCategory>> GetCategoriesAsync();
        Task<List<Recipe>> GetRecipesByCategoryAsync(string category);
    }
}
