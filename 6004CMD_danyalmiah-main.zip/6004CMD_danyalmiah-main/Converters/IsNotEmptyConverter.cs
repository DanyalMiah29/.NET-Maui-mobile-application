using System.Globalization;

namespace RecipeVault.Converters
{
    /// <summary>
    /// Returns true when a string is not null or empty.
    /// Used to conditionally show Quantity labels in ShoppingListPage.
    /// </summary>
    public class IsNotEmptyConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
            => !string.IsNullOrWhiteSpace(value as string);

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
