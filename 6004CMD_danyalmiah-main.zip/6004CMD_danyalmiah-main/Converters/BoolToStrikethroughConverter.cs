using System.Globalization;

namespace RecipeVault.Converters
{
    /// <summary>
    /// Converts a bool (IsChecked) to a TextDecorations value.
    /// True  → Strikethrough (item is checked/done)
    /// False → None
    /// </summary>
    public class BoolToStrikethroughConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
            => value is true ? TextDecorations.Strikethrough : TextDecorations.None;

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
