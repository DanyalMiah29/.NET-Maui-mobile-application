using System.Globalization;

namespace RecipeVault.Converters
{
    /// <summary>
    /// Converts a bool to one of two colours.
    /// Default: True → #FF6B35 (orange), False → #CCCCCC (grey)
    /// Used for favourite toggle icons.
    /// </summary>
    public class BoolToColorConverter : IValueConverter
    {
        public Color TrueColor  { get; set; } = Color.FromArgb("#FF6B35");
        public Color FalseColor { get; set; } = Color.FromArgb("#CCCCCC");

        public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
            => value is true ? TrueColor : FalseColor;

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
