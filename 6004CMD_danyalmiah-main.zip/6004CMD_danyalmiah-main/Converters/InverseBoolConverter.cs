using System.Globalization;

namespace RecipeVault.Converters
{
    /// <summary>
    /// Inverts a boolean value.  Used to show/hide elements as opposites.
    /// e.g. IsVisible="{Binding IsEmpty, Converter={StaticResource InverseBool}}"
    /// </summary>
    public class InverseBoolConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
            => value is bool b && !b;

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
            => value is bool b && !b;
    }
}
