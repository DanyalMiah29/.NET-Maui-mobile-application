using RecipeVault.ViewModels;

namespace RecipeVault.Views;

public partial class RecipeBrowsePage : ContentPage
{
    private readonly RecipeBrowseViewModel _vm;

    public RecipeBrowsePage(RecipeBrowseViewModel vm)
    {
        InitializeComponent();
        _vm            = vm;
        BindingContext = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        if (_vm.LoadCategoriesCommand.CanExecute(null))
            _vm.LoadCategoriesCommand.Execute(null);
    }
}
