using RecipeVault.ViewModels;

namespace RecipeVault.Views;

public partial class HomePage : ContentPage
{
    private readonly HomeViewModel _vm;

    public HomePage(HomeViewModel vm)
    {
        InitializeComponent();
        _vm            = vm;
        BindingContext = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        if (!_vm.IsBusy && _vm.LoadCommand.CanExecute(null))
            _vm.LoadCommand.Execute(null);
    }
}
