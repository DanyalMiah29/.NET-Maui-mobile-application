using RecipeVault.ViewModels;

namespace RecipeVault.Views;

public partial class ShoppingListPage : ContentPage
{
    private readonly ShoppingListViewModel _vm;

    public ShoppingListPage(ShoppingListViewModel vm)
    {
        InitializeComponent();
        _vm            = vm;
        BindingContext = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        if (_vm.LoadCommand.CanExecute(null))
            _vm.LoadCommand.Execute(null);
    }

    private void OnItemCheckedChanged(object? sender, CheckedChangedEventArgs e)
    {
        if (sender is CheckBox { BindingContext: RecipeVault.Models.ShoppingItem item }
            && _vm.ToggleCheckedCommand.CanExecute(item))
        {
            _vm.ToggleCheckedCommand.Execute(item);
        }
    }
}
