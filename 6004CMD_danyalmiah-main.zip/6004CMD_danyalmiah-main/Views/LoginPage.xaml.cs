using RecipeVault.ViewModels;

namespace RecipeVault.Views;

public partial class LoginPage : ContentPage
{
    private readonly LoginViewModel _vm;

    public LoginPage(LoginViewModel vm)
    {
        InitializeComponent();
        _vm         = vm;
        BindingContext = vm;
    }
}
