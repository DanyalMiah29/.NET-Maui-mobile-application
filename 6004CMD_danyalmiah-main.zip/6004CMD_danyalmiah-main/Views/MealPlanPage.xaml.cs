using RecipeVault.ViewModels;

namespace RecipeVault.Views;

public partial class MealPlanPage : ContentPage
{
    private readonly MealPlanViewModel _vm;

    public MealPlanPage(MealPlanViewModel vm)
    {
        InitializeComponent();
        _vm            = vm;
        BindingContext = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        if (_vm.LoadCommand.CanExecute(null))
            _vm.LoadCommand.Execute(null);
    }
}
