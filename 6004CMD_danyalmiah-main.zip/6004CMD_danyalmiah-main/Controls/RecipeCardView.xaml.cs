using RecipeVault.Models;

namespace RecipeVault.Controls;

/// <summary>
/// Custom ContentView control that renders a Recipe as a card.
/// Exposes a Recipe BindableProperty so it can be used with binding
/// in both code and XAML — demonstrating custom control creation.
/// Design pattern: Template Method (via ContentView), Facade (wraps complex layout)
/// </summary>
public partial class RecipeCardView : ContentView
{
    // ── BindableProperty: Recipe ───────────────────────────────────────────────
    public static readonly BindableProperty RecipeProperty =
        BindableProperty.Create(
            nameof(Recipe),
            typeof(Recipe),
            typeof(RecipeCardView),
            null,
            propertyChanged: OnRecipeChanged);

    public Recipe? Recipe
    {
        get => (Recipe?)GetValue(RecipeProperty);
        set => SetValue(RecipeProperty, value);
    }

    private static void OnRecipeChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is RecipeCardView card)
            card.BindingContext = newValue;
    }

    // ──────────────────────────────────────────────────────────────────────────

    public RecipeCardView()
    {
        InitializeComponent();
    }
}
