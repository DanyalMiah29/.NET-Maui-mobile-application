using Newtonsoft.Json;
using RecipeVault.Interfaces;
using RecipeVault.Models;

namespace RecipeVault.Services
{
    /// <summary>
    /// Fetches recipe data from TheMealDB public REST API (no key required).
    /// Base URL: https://www.themealdb.com/api/json/v1/1/
    ///
    /// Endpoints implemented:
    ///   1. search.php?s={name}        – search by meal name
    ///   2. lookup.php?i={id}          – look up full meal by ID
    ///   3. categories.php             – list all categories
    ///   4. filter.php?c={category}    – filter meals by category
    /// </summary>
    public class MealDbApiService : IRecipeApiService
    {
        private readonly HttpClient _http;
        private const string BaseUrl = "https://www.themealdb.com/api/json/v1/1/";

        public MealDbApiService(HttpClient http)
        {
            _http = http;
        }

        // Endpoint 1 – search by name
        public async Task<List<Recipe>> SearchRecipesAsync(string query)
        {
            try
            {
                var url      = $"{BaseUrl}search.php?s={Uri.EscapeDataString(query)}";
                var json     = await _http.GetStringAsync(url);
                var response = JsonConvert.DeserializeObject<MealDbSearchResponse>(json);
                return response?.Meals?.Select(m => m.ToRecipe()).ToList() ?? new List<Recipe>();
            }
            catch
            {
                return new List<Recipe>();
            }
        }

        // Endpoint 2 – lookup full detail by ID
        public async Task<Recipe?> GetRecipeByIdAsync(string mealDbId)
        {
            try
            {
                var url      = $"{BaseUrl}lookup.php?i={Uri.EscapeDataString(mealDbId)}";
                var json     = await _http.GetStringAsync(url);
                var response = JsonConvert.DeserializeObject<MealDbSearchResponse>(json);
                return response?.Meals?.FirstOrDefault()?.ToRecipe();
            }
            catch
            {
                return null;
            }
        }

        // Endpoint 3 – list all categories
        public async Task<List<MealDbCategory>> GetCategoriesAsync()
        {
            try
            {
                var url      = $"{BaseUrl}categories.php";
                var json     = await _http.GetStringAsync(url);
                var response = JsonConvert.DeserializeObject<MealDbCategoryResponse>(json);
                return response?.Categories ?? new List<MealDbCategory>();
            }
            catch
            {
                return new List<MealDbCategory>();
            }
        }

        // Endpoint 4 – filter by category (returns lightweight list, not full detail)
        public async Task<List<Recipe>> GetRecipesByCategoryAsync(string category)
        {
            try
            {
                var url  = $"{BaseUrl}filter.php?c={Uri.EscapeDataString(category)}";
                var json = await _http.GetStringAsync(url);

                // filter.php returns a different shape (only idMeal, strMeal, strMealThumb)
                var response = JsonConvert.DeserializeObject<MealDbSearchResponse>(json);
                return response?.Meals?.Select(m => m.ToRecipe()).ToList() ?? new List<Recipe>();
            }
            catch
            {
                return new List<Recipe>();
            }
        }
    }
}
