using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RecipeVault.Interfaces;
using RecipeVault.Models;
using System.Net.Http.Headers;

namespace RecipeVault.Services
{
    /// <summary>
    /// Implements cloud CRUD using the Firestore REST API.
    /// Collections:
    ///   users/{userId}/mealPlan       – MealPlanEntry documents
    ///   users/{userId}/shoppingList   – ShoppingItem documents
    ///
    /// Firestore REST docs:
    ///   https://firebase.google.com/docs/firestore/reference/rest
    /// </summary>
    public class FirestoreService : IFirestoreService
    {
        private readonly HttpClient _http;

        public FirestoreService(HttpClient http)
        {
            _http = http;
        }

        // ──────────────────────────────────────────────────────────────────────
        // MEAL PLAN
        // ──────────────────────────────────────────────────────────────────────

        public async Task<List<MealPlanEntry>> GetMealPlanAsync(string userId)
        {
            var url = $"{FirebaseConfig.FirestoreBaseUrl}/users/{userId}/mealPlan";
            try
            {
                var response = await _http.GetAsync(url);
                if (!response.IsSuccessStatusCode) return new();

                var body = await response.Content.ReadAsStringAsync();
                return ParseDocuments<MealPlanEntry>(body, MapMealPlanEntry);
            }
            catch { return new(); }
        }

        public async Task<string> AddMealPlanEntryAsync(MealPlanEntry entry, string idToken)
        {
            var url      = $"{FirebaseConfig.FirestoreBaseUrl}/users/{entry.UserId}/mealPlan";
            var document = BuildMealPlanDocument(entry);
            return await PostDocumentAsync(url, document, idToken);
        }

        public async Task UpdateMealPlanEntryAsync(MealPlanEntry entry, string idToken)
        {
            if (string.IsNullOrEmpty(entry.FirestoreDocId)) return;

            var url      = $"{FirebaseConfig.FirestoreBaseUrl}/users/{entry.UserId}/mealPlan/{entry.FirestoreDocId}";
            var document = BuildMealPlanDocument(entry);
            await PatchDocumentAsync(url, document, idToken);
        }

        public async Task DeleteMealPlanEntryAsync(string firestoreDocId, string userId, string idToken)
        {
            var url = $"{FirebaseConfig.FirestoreBaseUrl}/users/{userId}/mealPlan/{firestoreDocId}";
            await DeleteDocumentAsync(url, idToken);
        }

        // ──────────────────────────────────────────────────────────────────────
        // SHOPPING LIST
        // ──────────────────────────────────────────────────────────────────────

        public async Task<List<ShoppingItem>> GetShoppingItemsAsync(string userId)
        {
            var url = $"{FirebaseConfig.FirestoreBaseUrl}/users/{userId}/shoppingList";
            try
            {
                var response = await _http.GetAsync(url);
                if (!response.IsSuccessStatusCode) return new();

                var body = await response.Content.ReadAsStringAsync();
                return ParseDocuments<ShoppingItem>(body, MapShoppingItem);
            }
            catch { return new(); }
        }

        public async Task<string> AddShoppingItemAsync(ShoppingItem item, string idToken)
        {
            var url      = $"{FirebaseConfig.FirestoreBaseUrl}/users/{item.UserId}/shoppingList";
            var document = BuildShoppingItemDocument(item);
            return await PostDocumentAsync(url, document, idToken);
        }

        public async Task UpdateShoppingItemAsync(ShoppingItem item, string idToken)
        {
            if (string.IsNullOrEmpty(item.FirestoreDocId)) return;

            var url      = $"{FirebaseConfig.FirestoreBaseUrl}/users/{item.UserId}/shoppingList/{item.FirestoreDocId}";
            var document = BuildShoppingItemDocument(item);
            await PatchDocumentAsync(url, document, idToken);
        }

        public async Task DeleteShoppingItemAsync(string firestoreDocId, string userId, string idToken)
        {
            var url = $"{FirebaseConfig.FirestoreBaseUrl}/users/{userId}/shoppingList/{firestoreDocId}";
            await DeleteDocumentAsync(url, idToken);
        }

        // ──────────────────────────────────────────────────────────────────────
        // Generic HTTP helpers
        // ──────────────────────────────────────────────────────────────────────

        private async Task<string> PostDocumentAsync(string url, object document, string idToken)
        {
            try
            {
                var json    = JsonConvert.SerializeObject(document);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                var request = new HttpRequestMessage(HttpMethod.Post, url) { Content = content };
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", idToken);

                var response = await _http.SendAsync(request);
                if (!response.IsSuccessStatusCode) return string.Empty;

                var body = await response.Content.ReadAsStringAsync();
                var obj  = JObject.Parse(body);
                // name field: "projects/.../documents/{collection}/{docId}"
                var name = obj["name"]?.ToString() ?? string.Empty;
                return name.Split('/').LastOrDefault() ?? string.Empty;
            }
            catch { return string.Empty; }
        }

        private async Task PatchDocumentAsync(string url, object document, string idToken)
        {
            try
            {
                var json    = JsonConvert.SerializeObject(document);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                var request = new HttpRequestMessage(new HttpMethod("PATCH"), url) { Content = content };
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", idToken);
                await _http.SendAsync(request);
            }
            catch { /* swallow */ }
        }

        private async Task DeleteDocumentAsync(string url, string idToken)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Delete, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", idToken);
                await _http.SendAsync(request);
            }
            catch { /* swallow */ }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Firestore document builders (convert C# model → Firestore typed JSON)
        // ──────────────────────────────────────────────────────────────────────

        private static object BuildMealPlanDocument(MealPlanEntry e) => new
        {
            fields = new
            {
                userId         = Str(e.UserId),
                date           = Str(e.Date.ToString("o")),
                mealType       = Str(e.MealType),
                recipeName     = Str(e.RecipeName),
                recipeThumbnail= Str(e.RecipeThumbnail),
                mealDbId       = Str(e.MealDbId)
            }
        };

        private static object BuildShoppingItemDocument(ShoppingItem i) => new
        {
            fields = new
            {
                userId    = Str(i.UserId),
                name      = Str(i.Name),
                quantity  = Str(i.Quantity),
                isChecked = Bool(i.IsChecked),
                dateAdded = Str(i.DateAdded.ToString("o"))
            }
        };

        // ──────────────────────────────────────────────────────────────────────
        // Firestore typed-value helpers
        // ──────────────────────────────────────────────────────────────────────

        private static object Str(string  v) => new { stringValue  = v };
        private static object Bool(bool   v) => new { booleanValue = v };

        // ──────────────────────────────────────────────────────────────────────
        // Parser: converts a Firestore list response to a typed list
        // ──────────────────────────────────────────────────────────────────────

        private static List<T> ParseDocuments<T>(string json, Func<JObject, string, T?> mapper)
        {
            var result = new List<T>();
            try
            {
                var root       = JObject.Parse(json);
                var documents  = root["documents"] as JArray;
                if (documents is null) return result;

                foreach (JObject doc in documents)
                {
                    var name   = doc["name"]?.ToString() ?? string.Empty;
                    var docId  = name.Split('/').LastOrDefault() ?? string.Empty;
                    var fields = doc["fields"] as JObject;
                    if (fields is null) continue;

                    var item = mapper(fields, docId);
                    if (item is not null) result.Add(item);
                }
            }
            catch { /* return whatever we have */ }
            return result;
        }

        private static MealPlanEntry? MapMealPlanEntry(JObject fields, string docId)
        {
            try
            {
                var dateRaw = fields["date"]?["stringValue"]?.ToString();
                var date = DateTime.TryParse(dateRaw, out var parsedDate)
                    ? parsedDate
                    : DateTime.Today;

                return new MealPlanEntry
                {
                    FirestoreDocId   = docId,
                    UserId           = fields["userId"]?["stringValue"]?.ToString()          ?? string.Empty,
                    Date             = date,
                    MealType         = fields["mealType"]?["stringValue"]?.ToString()        ?? string.Empty,
                    RecipeName       = fields["recipeName"]?["stringValue"]?.ToString()      ?? string.Empty,
                    RecipeThumbnail  = fields["recipeThumbnail"]?["stringValue"]?.ToString() ?? string.Empty,
                    MealDbId         = fields["mealDbId"]?["stringValue"]?.ToString()        ?? string.Empty
                };
            }
            catch { return null; }
        }

        private static ShoppingItem? MapShoppingItem(JObject fields, string docId)
        {
            try
            {
                var dateRaw = fields["dateAdded"]?["stringValue"]?.ToString();
                var dateAdded = DateTime.TryParse(dateRaw, out var parsedDate)
                    ? parsedDate
                    : DateTime.UtcNow;

                return new ShoppingItem
                {
                    FirestoreDocId = docId,
                    UserId    = fields["userId"]?["stringValue"]?.ToString()   ?? string.Empty,
                    Name      = fields["name"]?["stringValue"]?.ToString()     ?? string.Empty,
                    Quantity  = fields["quantity"]?["stringValue"]?.ToString() ?? string.Empty,
                    IsChecked = fields["isChecked"]?["booleanValue"]?.Value<bool>() ?? false,
                    DateAdded = dateAdded
                };
            }
            catch { return null; }
        }
    }
}
