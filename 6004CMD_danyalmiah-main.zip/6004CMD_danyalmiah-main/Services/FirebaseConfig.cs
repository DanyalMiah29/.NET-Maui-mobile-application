namespace RecipeVault.Services
{
    /// <summary>
    /// Central place for all API keys and project configuration.
    /// Replace these values with your own Firebase project settings.
    /// Get them from: Firebase Console → Project Settings → General → Your apps → Web API Key
    /// </summary>
    public static class FirebaseConfig
    {
        // Firebase Web API Key (found in Firebase Console → Project Settings)
        public const string WebApiKey = "AIzaSyAaGQFYlI_8ve50sV4XJ_1vdJBMu0itg2I";

        // Firebase Project ID (found in Firebase Console → Project Settings)
        public const string ProjectId = "recipe-app-7f69f";

        // Firestore REST base URL
        public static string FirestoreBaseUrl =>
            $"https://firestore.googleapis.com/v1/projects/{ProjectId}/databases/(default)/documents";

        // Firebase Auth REST endpoints
        public const string SignUpUrl =
            "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=";
        public const string SignInUrl =
            "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=";
        public const string RefreshTokenUrl =
            "https://securetoken.googleapis.com/v1/token?key=";
    }
}
