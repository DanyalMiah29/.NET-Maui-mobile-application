using Newtonsoft.Json;
using RecipeVault.Interfaces;
using RecipeVault.Models;
using SQLite;

namespace RecipeVault.Services
{
    /// <summary>
    /// Wraps sqlite-net-pcl to provide local CRUD persistence.
    /// Tables: Recipes, MealPlanEntries, ShoppingItems
    /// Design pattern: Repository Pattern, Singleton (via DI registration)
    /// </summary>
    public class LocalDatabaseService : ILocalDatabaseService
    {
        private SQLiteAsyncConnection? _db;
        private bool _initialised;

        private static string DatabasePath =>
            Path.Combine(FileSystem.AppDataDirectory, "recipevault.db3");

        // ──────────────────────────────────────────────────────────────────────
        // INIT
        // ──────────────────────────────────────────────────────────────────────

        public async Task InitAsync()
        {
            if (_initialised) return;

            _db = new SQLiteAsyncConnection(
                DatabasePath,
                SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.SharedCache);

            await _db.CreateTableAsync<Recipe>();
            await _db.CreateTableAsync<MealPlanEntry>();
            await _db.CreateTableAsync<ShoppingItem>();
            _initialised = true;
        }

        private SQLiteAsyncConnection Db => _db
            ?? throw new InvalidOperationException("Database not initialised. Call InitAsync() first.");

        // ──────────────────────────────────────────────────────────────────────
        // RECIPES (Create, Read, Update, Delete)
        // ──────────────────────────────────────────────────────────────────────

        public async Task<List<Recipe>> GetAllRecipesAsync()
        {
            var list = await Db.Table<Recipe>().ToListAsync();
            DeserialiseIngredients(list);
            return list;
        }

        public async Task<List<Recipe>> GetFavoriteRecipesAsync()
        {
            var list = await Db.Table<Recipe>().Where(r => r.IsFavorite).ToListAsync();
            DeserialiseIngredients(list);
            return list;
        }

        public async Task<Recipe?> GetRecipeByMealDbIdAsync(string mealDbId)
        {
            var recipe = await Db.Table<Recipe>().Where(r => r.MealDbId == mealDbId).FirstOrDefaultAsync();
            if (recipe is not null)
                recipe.Ingredients = JsonConvert.DeserializeObject<List<Ingredient>>(recipe.IngredientsJson) ?? new();
            return recipe;
        }

        public async Task<int> SaveRecipeAsync(Recipe recipe)
        {
            recipe.IngredientsJson = JsonConvert.SerializeObject(recipe.Ingredients);
            var existing = await Db.Table<Recipe>().Where(r => r.MealDbId == recipe.MealDbId).FirstOrDefaultAsync();

            if (existing is null)
                return await Db.InsertAsync(recipe);

            recipe.Id = existing.Id;
            return await Db.UpdateAsync(recipe);
        }

        public Task<int> DeleteRecipeAsync(Recipe recipe) => Db.DeleteAsync(recipe);

        public async Task<bool> IsRecipeFavoriteAsync(string mealDbId)
        {
            var r = await Db.Table<Recipe>().Where(r => r.MealDbId == mealDbId).FirstOrDefaultAsync();
            return r?.IsFavorite ?? false;
        }

        public async Task ToggleFavoriteAsync(string mealDbId)
        {
            var recipe = await Db.Table<Recipe>().Where(r => r.MealDbId == mealDbId).FirstOrDefaultAsync();
            if (recipe is null) return;

            recipe.IsFavorite = !recipe.IsFavorite;
            await Db.UpdateAsync(recipe);
        }

        // ──────────────────────────────────────────────────────────────────────
        // MEAL PLAN (Create, Read, Delete)
        // ──────────────────────────────────────────────────────────────────────

        public Task<List<MealPlanEntry>> GetMealPlanEntriesAsync(string userId) =>
            Db.Table<MealPlanEntry>().Where(e => e.UserId == userId).ToListAsync();

        public Task<int> SaveMealPlanEntryAsync(MealPlanEntry entry)
        {
            if (entry.Id == 0)
                return Db.InsertAsync(entry);
            return Db.UpdateAsync(entry);
        }

        public Task<int> DeleteMealPlanEntryAsync(MealPlanEntry entry) => Db.DeleteAsync(entry);

        // ──────────────────────────────────────────────────────────────────────
        // SHOPPING LIST (Create, Read, Update, Delete)
        // ──────────────────────────────────────────────────────────────────────

        public Task<List<ShoppingItem>> GetShoppingItemsAsync(string userId) =>
            Db.Table<ShoppingItem>().Where(i => i.UserId == userId).ToListAsync();

        public Task<int> SaveShoppingItemAsync(ShoppingItem item)
        {
            if (item.Id == 0)
                return Db.InsertAsync(item);
            return Db.UpdateAsync(item);
        }

        public Task<int> DeleteShoppingItemAsync(ShoppingItem item) => Db.DeleteAsync(item);

        public Task<int> UpdateShoppingItemAsync(ShoppingItem item) => Db.UpdateAsync(item);

        // ──────────────────────────────────────────────────────────────────────
        // Helpers
        // ──────────────────────────────────────────────────────────────────────

        private static void DeserialiseIngredients(List<Recipe> recipes)
        {
            foreach (var r in recipes)
                r.Ingredients = JsonConvert.DeserializeObject<List<Ingredient>>(r.IngredientsJson) ?? new();
        }
    }
}
