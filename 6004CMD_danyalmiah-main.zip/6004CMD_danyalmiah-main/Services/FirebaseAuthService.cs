using Newtonsoft.Json;
using RecipeVault.Interfaces;
using RecipeVault.Models;

namespace RecipeVault.Services
{
    /// <summary>
    /// Implements Firebase Authentication using the Firebase Identity Toolkit REST API.
    /// Endpoints used:
    ///   POST accounts:signUp        – register a new user
    ///   POST accounts:signInWithPassword – sign in an existing user
    ///   POST token (securetoken)    – refresh the ID token
    /// Design patterns: Singleton (registered as singleton in DI), Repository (wraps HTTP)
    /// </summary>
    public class FirebaseAuthService : IAuthService
    {
        private readonly HttpClient _http;

        public UserProfile? CurrentUser { get; private set; }
        public bool IsLoggedIn => CurrentUser is not null && CurrentUser.IsTokenValid;

        public FirebaseAuthService(HttpClient http)
        {
            _http = http;
        }

        // ──────────────────────────────────────────────────────────────────────
        // REGISTER
        // ──────────────────────────────────────────────────────────────────────
        public async Task<(bool Success, string Message)> RegisterAsync(
            string email, string password, string displayName)
        {
            var payload = new
            {
                email,
                password,
                returnSecureToken = true
            };

            try
            {
                var json    = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                var response = await _http.PostAsync(
                    FirebaseConfig.SignUpUrl + FirebaseConfig.WebApiKey, content);

                var body = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var result = JsonConvert.DeserializeObject<FirebaseAuthResponse>(body);
                    CurrentUser = MapToUserProfile(result!, displayName);
                    return (true, "Registration successful.");
                }

                var error = JsonConvert.DeserializeObject<FirebaseErrorResponse>(body);
                return (false, FormatError(error?.Error?.Message));
            }
            catch (Exception ex)
            {
                return (false, $"Network error: {ex.Message}");
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // LOGIN
        // ──────────────────────────────────────────────────────────────────────
        public async Task<(bool Success, string Message)> LoginAsync(string email, string password)
        {
            var payload = new
            {
                email,
                password,
                returnSecureToken = true
            };

            try
            {
                var json    = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                var response = await _http.PostAsync(
                    FirebaseConfig.SignInUrl + FirebaseConfig.WebApiKey, content);

                var body = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var result = JsonConvert.DeserializeObject<FirebaseAuthResponse>(body);
                    var displayName = string.IsNullOrWhiteSpace(result?.DisplayName) ? "User" : result!.DisplayName!;
                    CurrentUser = MapToUserProfile(result!, displayName);
                    return (true, "Login successful.");
                }

                var error = JsonConvert.DeserializeObject<FirebaseErrorResponse>(body);
                return (false, FormatError(error?.Error?.Message));
            }
            catch (Exception ex)
            {
                return (false, $"Network error: {ex.Message}");
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // LOGOUT
        // ──────────────────────────────────────────────────────────────────────
        public Task LogoutAsync()
        {
            CurrentUser = null;
            return Task.CompletedTask;
        }

        // ──────────────────────────────────────────────────────────────────────
        // REFRESH TOKEN
        // ──────────────────────────────────────────────────────────────────────
        public async Task<bool> RefreshTokenAsync()
        {
            if (CurrentUser is null) return false;

            var payload = new
            {
                grant_type    = "refresh_token",
                refresh_token = CurrentUser.RefreshToken
            };

            try
            {
                var json    = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                var response = await _http.PostAsync(
                    FirebaseConfig.RefreshTokenUrl + FirebaseConfig.WebApiKey, content);

                if (!response.IsSuccessStatusCode) return false;

                var body   = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<FirebaseRefreshResponse>(body);

                if (result is null) return false;

                CurrentUser.IdToken      = result.IdToken;
                CurrentUser.RefreshToken = result.RefreshToken;
                CurrentUser.TokenExpiry  = DateTime.UtcNow.AddSeconds(
                    double.TryParse(result.ExpiresIn, out var sec) ? sec : 3600);

                return true;
            }
            catch
            {
                return false;
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Helpers
        // ──────────────────────────────────────────────────────────────────────

        private static UserProfile MapToUserProfile(FirebaseAuthResponse r, string displayName)
        {
            return new UserProfile
            {
                UserId       = r.LocalId,
                Email        = r.Email,
                DisplayName  = displayName,
                IdToken      = r.IdToken,
                RefreshToken = r.RefreshToken,
                TokenExpiry  = DateTime.UtcNow.AddSeconds(
                    double.TryParse(r.ExpiresIn, out var sec) ? sec : 3600)
            };
        }

        private static string FormatError(string? code) => code switch
        {
            "EMAIL_EXISTS"              => "An account with this email already exists.",
            "EMAIL_NOT_FOUND"           => "No account found with this email.",
            "INVALID_PASSWORD"          => "Incorrect password.",
            "INVALID_LOGIN_CREDENTIALS" => "Incorrect email or password.",
            "USER_DISABLED"             => "This account has been disabled.",
            "WEAK_PASSWORD : Password should be at least 6 characters"
                                        => "Password must be at least 6 characters.",
            _                           => code ?? "An unexpected error occurred."
        };

        // ── Private DTO classes (only used by this service) ───────────────────
        private class FirebaseAuthResponse
        {
            [JsonProperty("localId")]      public string LocalId { get; set; } = string.Empty;
            [JsonProperty("email")]        public string Email { get; set; } = string.Empty;
            [JsonProperty("displayName")]  public string? DisplayName { get; set; }
            [JsonProperty("idToken")]      public string IdToken { get; set; } = string.Empty;
            [JsonProperty("refreshToken")] public string RefreshToken { get; set; } = string.Empty;
            [JsonProperty("expiresIn")]    public string ExpiresIn { get; set; } = "3600";
        }

        private class FirebaseRefreshResponse
        {
            [JsonProperty("id_token")]      public string IdToken { get; set; } = string.Empty;
            [JsonProperty("refresh_token")] public string RefreshToken { get; set; } = string.Empty;
            [JsonProperty("expires_in")]    public string ExpiresIn { get; set; } = "3600";
        }

        private class FirebaseErrorResponse
        {
            [JsonProperty("error")] public FirebaseError? Error { get; set; }
        }

        private class FirebaseError
        {
            [JsonProperty("message")] public string? Message { get; set; }
        }
    }
}
