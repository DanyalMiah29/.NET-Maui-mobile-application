namespace RecipeVault.Models
{
    /// <summary>
    /// Holds the authenticated user's profile data returned from Firebase Auth.
    /// Stored in-memory (singleton service) for the session.
    /// </summary>
    public class UserProfile
    {
        public string UserId { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string IdToken { get; set; } = string.Empty;
        public string RefreshToken { get; set; } = string.Empty;
        public DateTime TokenExpiry { get; set; }

        public bool IsTokenValid => DateTime.UtcNow < TokenExpiry;
    }
}
