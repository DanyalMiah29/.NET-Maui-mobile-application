namespace RecipeVault.Models
{
    /// <summary>
    /// Represents a single ingredient with its measure.
    /// Stored as JSON within the Recipe model.
    /// </summary>
    public class Ingredient
    {
        public string Name { get; set; } = string.Empty;
        public string Measure { get; set; } = string.Empty;
    }
}
