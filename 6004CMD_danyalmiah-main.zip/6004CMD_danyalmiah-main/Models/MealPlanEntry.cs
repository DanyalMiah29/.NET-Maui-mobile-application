using SQLite;

namespace RecipeVault.Models
{
    /// <summary>
    /// Represents a meal planned for a specific day and meal type.
    /// Synced to Firestore for cloud persistence.
    /// </summary>
    [Table("MealPlanEntries")]
    public class MealPlanEntry
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public string UserId { get; set; } = string.Empty;
        public DateTime Date { get; set; } = DateTime.Today;
        public string MealType { get; set; } = string.Empty;   // Breakfast / Lunch / Dinner
        public string RecipeName { get; set; } = string.Empty;
        public string RecipeThumbnail { get; set; } = string.Empty;
        public string MealDbId { get; set; } = string.Empty;

        // Firestore document ID for cloud sync / deletion
        public string FirestoreDocId { get; set; } = string.Empty;
    }
}
