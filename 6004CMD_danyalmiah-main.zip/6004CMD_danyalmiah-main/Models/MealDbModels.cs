using Newtonsoft.Json;

namespace RecipeVault.Models
{
    // ──────────────────────────────────────────────────────────
    // TheMealDB REST API response DTOs
    // Source: https://www.themealdb.com/api.php
    // ──────────────────────────────────────────────────────────

    public class MealDbSearchResponse
    {
        [JsonProperty("meals")]
        public List<MealDbMeal>? Meals { get; set; }
    }

    public class MealDbCategoryResponse
    {
        [JsonProperty("categories")]
        public List<MealDbCategory>? Categories { get; set; }
    }

    public class MealDbCategory
    {
        [JsonProperty("idCategory")]   public string IdCategory { get; set; } = string.Empty;
        [JsonProperty("strCategory")]  public string Name { get; set; } = string.Empty;
        [JsonProperty("strCategoryThumb")] public string Thumbnail { get; set; } = string.Empty;
        [JsonProperty("strCategoryDescription")] public string Description { get; set; } = string.Empty;
    }

    /// <summary>
    /// Maps the flat TheMealDB meal JSON (which contains strIngredient1..20)
    /// into a structured object.
    /// </summary>
    public class MealDbMeal
    {
        [JsonProperty("idMeal")]          public string IdMeal { get; set; } = string.Empty;
        [JsonProperty("strMeal")]         public string Name { get; set; } = string.Empty;
        [JsonProperty("strCategory")]     public string Category { get; set; } = string.Empty;
        [JsonProperty("strArea")]         public string Area { get; set; } = string.Empty;
        [JsonProperty("strInstructions")] public string Instructions { get; set; } = string.Empty;
        [JsonProperty("strMealThumb")]    public string ThumbnailUrl { get; set; } = string.Empty;
        [JsonProperty("strTags")]         public string Tags { get; set; } = string.Empty;

        // Flat ingredient / measure pairs (TheMealDB uses 1..20 suffixes)
        [JsonProperty("strIngredient1")]  public string? Ingredient1 { get; set; }
        [JsonProperty("strIngredient2")]  public string? Ingredient2 { get; set; }
        [JsonProperty("strIngredient3")]  public string? Ingredient3 { get; set; }
        [JsonProperty("strIngredient4")]  public string? Ingredient4 { get; set; }
        [JsonProperty("strIngredient5")]  public string? Ingredient5 { get; set; }
        [JsonProperty("strIngredient6")]  public string? Ingredient6 { get; set; }
        [JsonProperty("strIngredient7")]  public string? Ingredient7 { get; set; }
        [JsonProperty("strIngredient8")]  public string? Ingredient8 { get; set; }
        [JsonProperty("strIngredient9")]  public string? Ingredient9 { get; set; }
        [JsonProperty("strIngredient10")] public string? Ingredient10 { get; set; }
        [JsonProperty("strIngredient11")] public string? Ingredient11 { get; set; }
        [JsonProperty("strIngredient12")] public string? Ingredient12 { get; set; }
        [JsonProperty("strIngredient13")] public string? Ingredient13 { get; set; }
        [JsonProperty("strIngredient14")] public string? Ingredient14 { get; set; }
        [JsonProperty("strIngredient15")] public string? Ingredient15 { get; set; }
        [JsonProperty("strIngredient16")] public string? Ingredient16 { get; set; }
        [JsonProperty("strIngredient17")] public string? Ingredient17 { get; set; }
        [JsonProperty("strIngredient18")] public string? Ingredient18 { get; set; }
        [JsonProperty("strIngredient19")] public string? Ingredient19 { get; set; }
        [JsonProperty("strIngredient20")] public string? Ingredient20 { get; set; }

        [JsonProperty("strMeasure1")]  public string? Measure1 { get; set; }
        [JsonProperty("strMeasure2")]  public string? Measure2 { get; set; }
        [JsonProperty("strMeasure3")]  public string? Measure3 { get; set; }
        [JsonProperty("strMeasure4")]  public string? Measure4 { get; set; }
        [JsonProperty("strMeasure5")]  public string? Measure5 { get; set; }
        [JsonProperty("strMeasure6")]  public string? Measure6 { get; set; }
        [JsonProperty("strMeasure7")]  public string? Measure7 { get; set; }
        [JsonProperty("strMeasure8")]  public string? Measure8 { get; set; }
        [JsonProperty("strMeasure9")]  public string? Measure9 { get; set; }
        [JsonProperty("strMeasure10")] public string? Measure10 { get; set; }
        [JsonProperty("strMeasure11")] public string? Measure11 { get; set; }
        [JsonProperty("strMeasure12")] public string? Measure12 { get; set; }
        [JsonProperty("strMeasure13")] public string? Measure13 { get; set; }
        [JsonProperty("strMeasure14")] public string? Measure14 { get; set; }
        [JsonProperty("strMeasure15")] public string? Measure15 { get; set; }
        [JsonProperty("strMeasure16")] public string? Measure16 { get; set; }
        [JsonProperty("strMeasure17")] public string? Measure17 { get; set; }
        [JsonProperty("strMeasure18")] public string? Measure18 { get; set; }
        [JsonProperty("strMeasure19")] public string? Measure19 { get; set; }
        [JsonProperty("strMeasure20")] public string? Measure20 { get; set; }

        /// <summary>
        /// Converts the flat fields into a clean Ingredient list.
        /// </summary>
        public List<Ingredient> GetIngredients()
        {
            var names    = new[] { Ingredient1, Ingredient2, Ingredient3, Ingredient4, Ingredient5,
                                   Ingredient6, Ingredient7, Ingredient8, Ingredient9, Ingredient10,
                                   Ingredient11, Ingredient12, Ingredient13, Ingredient14, Ingredient15,
                                   Ingredient16, Ingredient17, Ingredient18, Ingredient19, Ingredient20 };
            var measures = new[] { Measure1, Measure2, Measure3, Measure4, Measure5,
                                   Measure6, Measure7, Measure8, Measure9, Measure10,
                                   Measure11, Measure12, Measure13, Measure14, Measure15,
                                   Measure16, Measure17, Measure18, Measure19, Measure20 };

            var result = new List<Ingredient>();
            for (int i = 0; i < names.Length; i++)
            {
                if (!string.IsNullOrWhiteSpace(names[i]))
                    result.Add(new Ingredient { Name = names[i]!, Measure = measures[i] ?? string.Empty });
            }
            return result;
        }

        /// <summary>Converts to the local Recipe domain model.</summary>
        public Recipe ToRecipe()
        {
            var ingredients = GetIngredients();
            return new Recipe
            {
                MealDbId       = IdMeal,
                Name           = Name,
                Category       = Category,
                Area           = Area,
                Instructions   = Instructions,
                ThumbnailUrl   = ThumbnailUrl,
                Tags           = Tags ?? string.Empty,
                IngredientsJson = Newtonsoft.Json.JsonConvert.SerializeObject(ingredients),
                Ingredients    = ingredients
            };
        }
    }
}
