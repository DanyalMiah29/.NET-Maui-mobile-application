using SQLite;

namespace RecipeVault.Models
{
    /// <summary>
    /// Represents an item on the shopping list.
    /// Synced to Firestore for cloud persistence.
    /// </summary>
    [Table("ShoppingItems")]
    public class ShoppingItem
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public string UserId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Quantity { get; set; } = string.Empty;
        public bool IsChecked { get; set; }
        public DateTime DateAdded { get; set; } = DateTime.UtcNow;

        // Firestore document ID for cloud sync / deletion
        public string FirestoreDocId { get; set; } = string.Empty;
    }
}
