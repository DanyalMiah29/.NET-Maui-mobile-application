using SQLite;

namespace RecipeVault.Models
{
    /// <summary>
    /// Represents a recipe stored locally in SQLite.
    /// Maps to TheMealDB API meal data.
    /// </summary>
    [Table("Recipes")]
    public class Recipe
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        [Indexed]
        public string MealDbId { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Area { get; set; } = string.Empty;
        public string Instructions { get; set; } = string.Empty;
        public string ThumbnailUrl { get; set; } = string.Empty;
        public string Tags { get; set; } = string.Empty;
        public bool IsFavorite { get; set; }
        public DateTime DateAdded { get; set; } = DateTime.UtcNow;

        // Stored as JSON string to avoid a separate table
        public string IngredientsJson { get; set; } = "[]";

        [Ignore]
        public List<Ingredient> Ingredients { get; set; } = new();
    }
}
