using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;

namespace RecipeVault.ViewModels
{
    public partial class ProfileViewModel : BaseViewModel
    {
        private readonly IAuthService          _auth;
        private readonly ILocalDatabaseService _localDb;

        [ObservableProperty] private string _displayName  = string.Empty;
        [ObservableProperty] private string _email        = string.Empty;
        [ObservableProperty] private int    _favoriteCount;
        [ObservableProperty] private int    _mealPlanCount;
        [ObservableProperty] private int    _shoppingCount;

        public ProfileViewModel(IAuthService auth, ILocalDatabaseService localDb)
        {
            _auth    = auth;
            _localDb = localDb;
            Title    = "Profile";
        }

        [RelayCommand]
        private async Task LoadAsync()
        {
            if (!_auth.IsLoggedIn) return;

            DisplayName = _auth.CurrentUser!.DisplayName;
            Email       = _auth.CurrentUser.Email;

            try
            {
                await _localDb.InitAsync();
                var favs  = await _localDb.GetFavoriteRecipesAsync();
                var plan  = await _localDb.GetMealPlanEntriesAsync(_auth.CurrentUser.UserId);
                var shop  = await _localDb.GetShoppingItemsAsync(_auth.CurrentUser.UserId);

                FavoriteCount  = favs.Count;
                MealPlanCount  = plan.Count;
                ShoppingCount  = shop.Count;
            }
            catch { /* stats are non-critical */ }
        }

        [RelayCommand]
        private async Task LogoutAsync()
        {
            bool confirm = await Shell.Current.DisplayAlert(
                "Sign Out", "Are you sure you want to sign out?", "Yes", "Cancel");

            if (!confirm) return;

            await _auth.LogoutAsync();
            await Shell.Current.GoToAsync("//login");
        }
    }
}
