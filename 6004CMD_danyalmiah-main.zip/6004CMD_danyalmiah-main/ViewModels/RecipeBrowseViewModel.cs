using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;
using RecipeVault.Models;
using System.Collections.ObjectModel;

namespace RecipeVault.ViewModels
{
    public partial class RecipeBrowseViewModel : BaseViewModel, IQueryAttributable
    {
        private readonly IRecipeApiService     _recipeApi;
        private readonly ILocalDatabaseService _localDb;

        [ObservableProperty] private ObservableCollection<Recipe> _recipes    = new();
        [ObservableProperty] private ObservableCollection<MealDbCategory> _categories = new();
        [ObservableProperty] private string _searchQuery       = string.Empty;
        [ObservableProperty] private string _selectedCategory  = string.Empty;
        [ObservableProperty] private bool   _isEmptyState;

        public RecipeBrowseViewModel(IRecipeApiService recipeApi, ILocalDatabaseService localDb)
        {
            _recipeApi = recipeApi;
            _localDb   = localDb;
            Title      = "Browse Recipes";
        }

        [RelayCommand]
        private async Task LoadCategoriesAsync()
        {
            IsBusy = true;
            ClearError();
            try
            {
                var cats = await _recipeApi.GetCategoriesAsync();
                Categories = new ObservableCollection<MealDbCategory>(cats);
            }
            catch (Exception ex)
            {
                SetError($"Could not load categories: {ex.Message}");
            }
            finally { IsBusy = false; }
        }

        [RelayCommand]
        private async Task SearchAsync()
        {
            if (string.IsNullOrWhiteSpace(SearchQuery)) return;

            IsBusy = true;
            ClearError();
            try
            {
                var results = await _recipeApi.SearchRecipesAsync(SearchQuery);
                Recipes       = new ObservableCollection<Recipe>(results);
                IsEmptyState  = !results.Any();
            }
            catch (Exception ex)
            {
                SetError($"Search failed: {ex.Message}");
            }
            finally { IsBusy = false; }
        }

        [RelayCommand]
        private async Task FilterByCategoryAsync(MealDbCategory category)
        {
            if (category is null || string.IsNullOrWhiteSpace(category.Name)) return;

            SelectedCategory = category.Name;
            IsBusy           = true;
            ClearError();
            try
            {
                var results  = await _recipeApi.GetRecipesByCategoryAsync(category.Name);
                Recipes      = new ObservableCollection<Recipe>(results);
                IsEmptyState = !results.Any();
            }
            catch (Exception ex)
            {
                SetError($"Filter failed: {ex.Message}");
            }
            finally { IsBusy = false; }
        }

        [RelayCommand]
        private async Task OpenRecipeAsync(Recipe recipe)
        {
            if (recipe is null) return;

            if (string.IsNullOrEmpty(recipe.Instructions))
            {
                // filter.php returns incomplete recipes → fetch full detail
                var full = await _recipeApi.GetRecipeByIdAsync(recipe.MealDbId);
                if (full is not null) recipe = full;
            }

            await Shell.Current.GoToAsync("recipeDetail",
                new Dictionary<string, object> { ["Recipe"] = recipe });
        }

        public async void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            if (query is null) return;

            if (query.TryGetValue("Category", out var categoryObj) && categoryObj is MealDbCategory category)
            {
                await FilterByCategoryAsync(category);
            }
        }
    }
}
