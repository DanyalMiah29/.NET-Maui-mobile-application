using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;

namespace RecipeVault.ViewModels
{
    public partial class RegisterViewModel : BaseViewModel
    {
        private readonly IAuthService _auth;

        [ObservableProperty] private string _displayName = string.Empty;
        [ObservableProperty] private string _email       = string.Empty;
        [ObservableProperty] private string _password    = string.Empty;
        [ObservableProperty] private string _confirmPassword = string.Empty;

        public RegisterViewModel(IAuthService auth)
        {
            _auth = auth;
            Title = "Create Account";
        }

        [RelayCommand]
        private async Task RegisterAsync()
        {
            ClearError();

            if (string.IsNullOrWhiteSpace(DisplayName) ||
                string.IsNullOrWhiteSpace(Email)       ||
                string.IsNullOrWhiteSpace(Password))
            {
                SetError("All fields are required.");
                return;
            }

            if (Password != ConfirmPassword)
            {
                SetError("Passwords do not match.");
                return;
            }

            if (Password.Length < 6)
            {
                SetError("Password must be at least 6 characters.");
                return;
            }

            IsBusy = true;
            try
            {
                var (success, message) = await _auth.RegisterAsync(Email, Password, DisplayName);

                if (success)
                    await Shell.Current.GoToAsync("//home");
                else
                    SetError(message);
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        private async Task GoBackAsync() => await Shell.Current.GoToAsync("..");
    }
}
