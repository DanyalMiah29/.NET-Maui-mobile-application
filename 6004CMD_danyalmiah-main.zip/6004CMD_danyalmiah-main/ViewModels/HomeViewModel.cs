using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;
using RecipeVault.Models;
using System.Collections.ObjectModel;

namespace RecipeVault.ViewModels
{
    public partial class HomeViewModel : BaseViewModel
    {
        private readonly IRecipeApiService    _recipeApi;
        private readonly ILocalDatabaseService _localDb;
        private readonly IAuthService          _auth;

        [ObservableProperty] private ObservableCollection<Recipe> _featuredRecipes = new();
        [ObservableProperty] private ObservableCollection<MealDbCategory> _categories = new();
        [ObservableProperty] private string _welcomeMessage = string.Empty;

        public HomeViewModel(IRecipeApiService recipeApi, ILocalDatabaseService localDb, IAuthService auth)
        {
            _recipeApi = recipeApi;
            _localDb   = localDb;
            _auth      = auth;
            Title      = "RecipeVault";
        }

        [RelayCommand]
        private async Task LoadAsync()
        {
            IsBusy = true;
            ClearError();

            try
            {
                var rawName = _auth.CurrentUser?.DisplayName;
                var displayName = string.IsNullOrWhiteSpace(rawName) ? "User" : rawName;

                WelcomeMessage = _auth.IsLoggedIn
                    ? $"Welcome back, {displayName}!"
                    : "Welcome to RecipeVault!";

                await _localDb.InitAsync();

                // Load featured recipes (random picks via search)
                var recipes    = await _recipeApi.SearchRecipesAsync("chicken");
                FeaturedRecipes = new ObservableCollection<Recipe>(recipes.Take(6));

                // Load categories
                var cats = await _recipeApi.GetCategoriesAsync();
                Categories = new ObservableCollection<MealDbCategory>(cats.Take(8));
            }
            catch (Exception ex)
            {
                SetError($"Could not load content: {ex.Message}");
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        private async Task OpenRecipeAsync(Recipe recipe)
        {
            if (recipe is null) return;

            await Shell.Current.GoToAsync("recipeDetail",
                new Dictionary<string, object> { ["Recipe"] = recipe });
        }

        [RelayCommand]
        private async Task OpenBrowseAsync() =>
            await Shell.Current.GoToAsync("//browse");

        [RelayCommand]
        private async Task OpenCategoryAsync(MealDbCategory category)
        {
            if (category is null) return;

            await Shell.Current.GoToAsync("//browse",
                new Dictionary<string, object> { ["Category"] = category });
        }
    }
}
