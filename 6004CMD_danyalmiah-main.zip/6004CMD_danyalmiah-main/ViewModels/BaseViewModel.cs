using CommunityToolkit.Mvvm.ComponentModel;

namespace RecipeVault.ViewModels
{
    /// <summary>
    /// Base ViewModel inheriting ObservableObject from CommunityToolkit.Mvvm.
    /// Provides common IsBusy / Title infrastructure (DRY principle).
    /// All ViewModels in RecipeVault extend this class.
    /// Design pattern: Template Method (base behaviour shared via inheritance)
    /// </summary>
    public partial class BaseViewModel : ObservableObject
    {
        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(IsNotBusy))]
        private bool _isBusy;

        [ObservableProperty]
        private string _title = string.Empty;

        [ObservableProperty]
        private string _errorMessage = string.Empty;

        [ObservableProperty]
        private bool _hasError;

        public bool IsNotBusy => !IsBusy;

        protected void SetError(string message)
        {
            ErrorMessage = message;
            HasError     = !string.IsNullOrEmpty(message);
        }

        protected void ClearError()
        {
            ErrorMessage = string.Empty;
            HasError     = false;
        }
    }
}
