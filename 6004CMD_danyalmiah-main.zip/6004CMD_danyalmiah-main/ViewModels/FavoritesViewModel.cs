using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;
using RecipeVault.Models;
using System.Collections.ObjectModel;

namespace RecipeVault.ViewModels
{
    public partial class FavoritesViewModel : BaseViewModel
    {
        private readonly ILocalDatabaseService _localDb;

        [ObservableProperty] private ObservableCollection<Recipe> _favorites = new();
        [ObservableProperty] private bool _isEmpty;

        public FavoritesViewModel(ILocalDatabaseService localDb)
        {
            _localDb = localDb;
            Title    = "My Favourites";
        }

        [RelayCommand]
        private async Task LoadAsync()
        {
            IsBusy = true;
            ClearError();
            try
            {
                await _localDb.InitAsync();
                var list  = await _localDb.GetFavoriteRecipesAsync();
                Favorites = new ObservableCollection<Recipe>(list);
                IsEmpty   = !list.Any();
            }
            catch (Exception ex) { SetError(ex.Message); }
            finally { IsBusy = false; }
        }

        [RelayCommand]
        private async Task RemoveFavoriteAsync(Recipe recipe)
        {
            await _localDb.ToggleFavoriteAsync(recipe.MealDbId);
            Favorites.Remove(recipe);
            IsEmpty = !Favorites.Any();
        }

        [RelayCommand]
        private async Task OpenRecipeAsync(Recipe recipe)
        {
            await Shell.Current.GoToAsync("recipeDetail",
                new Dictionary<string, object> { ["Recipe"] = recipe });
        }
    }
}
