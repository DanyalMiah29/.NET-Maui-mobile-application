using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;
using RecipeVault.Models;
using System.Collections.ObjectModel;

namespace RecipeVault.ViewModels
{
    public partial class MealPlanViewModel : BaseViewModel
    {
        private readonly ILocalDatabaseService _localDb;
        private readonly IFirestoreService     _firestore;
        private readonly IAuthService          _auth;

        [ObservableProperty] private ObservableCollection<MealPlanEntry> _entries = new();
        [ObservableProperty] private DateTime _selectedDate = DateTime.Today;
        [ObservableProperty] private bool     _isEmpty;

        public MealPlanViewModel(ILocalDatabaseService localDb, IFirestoreService firestore, IAuthService auth)
        {
            _localDb   = localDb;
            _firestore = firestore;
            _auth      = auth;
            Title      = "Meal Plan";
        }

        [RelayCommand]
        private async Task LoadAsync()
        {
            if (!_auth.IsLoggedIn) return;

            IsBusy = true;
            ClearError();
            try
            {
                await _localDb.InitAsync();
                var list = await _localDb.GetMealPlanEntriesAsync(_auth.CurrentUser!.UserId);

                // Merge cloud entries (cloud is source of truth)
                var cloud = await _firestore.GetMealPlanAsync(_auth.CurrentUser.UserId);
                foreach (var ce in cloud)
                {
                    if (!list.Any(l => l.FirestoreDocId == ce.FirestoreDocId))
                    {
                        ce.UserId = _auth.CurrentUser.UserId;
                        await _localDb.SaveMealPlanEntryAsync(ce);
                        list.Add(ce);
                    }
                }

                var filtered = list
                    .Where(e => e.Date.Date == SelectedDate.Date)
                    .OrderBy(e => e.MealType)
                    .ToList();

                Entries  = new ObservableCollection<MealPlanEntry>(filtered);
                IsEmpty  = !Entries.Any();
            }
            catch (Exception ex) { SetError(ex.Message); }
            finally { IsBusy = false; }
        }

        partial void OnSelectedDateChanged(DateTime value) => _ = LoadAsync();

        [RelayCommand]
        private async Task DeleteEntryAsync(MealPlanEntry entry)
        {
            if (entry is null || !_auth.IsLoggedIn) return;

            ClearError();
            try
            {
                await _localDb.DeleteMealPlanEntryAsync(entry);

                if (!string.IsNullOrEmpty(entry.FirestoreDocId))
                    await _firestore.DeleteMealPlanEntryAsync(
                        entry.FirestoreDocId, entry.UserId, _auth.CurrentUser!.IdToken);

                Entries.Remove(entry);
                IsEmpty = !Entries.Any();
            }
            catch (Exception ex)
            {
                SetError($"Could not delete meal plan entry: {ex.Message}");
            }
        }
    }
}
