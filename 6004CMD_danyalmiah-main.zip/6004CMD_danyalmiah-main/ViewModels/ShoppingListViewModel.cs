using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;
using RecipeVault.Models;
using System.Collections.ObjectModel;

namespace RecipeVault.ViewModels
{
    public partial class ShoppingListViewModel : BaseViewModel
    {
        private readonly ILocalDatabaseService _localDb;
        private readonly IFirestoreService     _firestore;
        private readonly IAuthService          _auth;

        [ObservableProperty] private ObservableCollection<ShoppingItem> _items = new();
        [ObservableProperty] private string _newItemName     = string.Empty;
        [ObservableProperty] private string _newItemQuantity = string.Empty;
        [ObservableProperty] private bool   _isEmpty;

        public ShoppingListViewModel(ILocalDatabaseService localDb, IFirestoreService firestore, IAuthService auth)
        {
            _localDb   = localDb;
            _firestore = firestore;
            _auth      = auth;
            Title      = "Shopping List";
        }

        [RelayCommand]
        private async Task LoadAsync()
        {
            if (!_auth.IsLoggedIn) return;

            IsBusy = true;
            ClearError();
            try
            {
                await _localDb.InitAsync();
                var list = await _localDb.GetShoppingItemsAsync(_auth.CurrentUser!.UserId);

                // Sync from Firestore
                var cloud = await _firestore.GetShoppingItemsAsync(_auth.CurrentUser.UserId);
                foreach (var ci in cloud)
                {
                    if (!list.Any(l => l.FirestoreDocId == ci.FirestoreDocId))
                    {
                        ci.UserId = _auth.CurrentUser.UserId;
                        await _localDb.SaveShoppingItemAsync(ci);
                        list.Add(ci);
                    }
                }

                Items   = new ObservableCollection<ShoppingItem>(list.OrderBy(i => i.IsChecked));
                IsEmpty = !Items.Any();
            }
            catch (Exception ex) { SetError(ex.Message); }
            finally { IsBusy = false; }
        }

        [RelayCommand]
        private async Task AddItemAsync()
        {
            if (!_auth.IsLoggedIn || string.IsNullOrWhiteSpace(NewItemName)) return;

            ClearError();
            try
            {
                var item = new ShoppingItem
                {
                    UserId   = _auth.CurrentUser!.UserId,
                    Name     = NewItemName.Trim(),
                    Quantity = NewItemQuantity.Trim(),
                    DateAdded = DateTime.UtcNow
                };

                await _localDb.InitAsync();
                await _localDb.SaveShoppingItemAsync(item);

                var docId = await _firestore.AddShoppingItemAsync(item, _auth.CurrentUser.IdToken);
                if (!string.IsNullOrEmpty(docId))
                {
                    item.FirestoreDocId = docId;
                    await _localDb.UpdateShoppingItemAsync(item);
                }

                Items.Insert(0, item);
                IsEmpty          = false;
                NewItemName      = string.Empty;
                NewItemQuantity  = string.Empty;
            }
            catch (Exception ex)
            {
                SetError($"Could not add item: {ex.Message}");
            }
        }

        [RelayCommand]
        private async Task ToggleCheckedAsync(ShoppingItem item)
        {
            if (item is null || !_auth.IsLoggedIn) return;

            try
            {
                await _localDb.UpdateShoppingItemAsync(item);

                if (!string.IsNullOrEmpty(item.FirestoreDocId))
                    await _firestore.UpdateShoppingItemAsync(item, _auth.CurrentUser!.IdToken);

                // Re-sort: unchecked first
                var sorted = Items.OrderBy(i => i.IsChecked).ToList();
                Items = new ObservableCollection<ShoppingItem>(sorted);
            }
            catch (Exception ex)
            {
                SetError($"Could not update item: {ex.Message}");
            }
        }

        [RelayCommand]
        private async Task DeleteItemAsync(ShoppingItem item)
        {
            if (item is null || !_auth.IsLoggedIn) return;

            try
            {
                await _localDb.DeleteShoppingItemAsync(item);

                if (!string.IsNullOrEmpty(item.FirestoreDocId))
                    await _firestore.DeleteShoppingItemAsync(
                        item.FirestoreDocId, item.UserId, _auth.CurrentUser!.IdToken);

                Items.Remove(item);
                IsEmpty = !Items.Any();
            }
            catch (Exception ex)
            {
                SetError($"Could not delete item: {ex.Message}");
            }
        }

        [RelayCommand]
        private async Task ClearCheckedAsync()
        {
            var checked_ = Items.Where(i => i.IsChecked).ToList();
            foreach (var item in checked_)
                await DeleteItemAsync(item);
        }
    }
}
