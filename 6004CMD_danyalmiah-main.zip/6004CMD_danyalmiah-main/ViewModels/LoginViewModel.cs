using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;

namespace RecipeVault.ViewModels
{
    public partial class LoginViewModel : BaseViewModel
    {
        private readonly IAuthService _auth;

        [ObservableProperty] private string _email    = string.Empty;
        [ObservableProperty] private string _password = string.Empty;

        public LoginViewModel(IAuthService auth)
        {
            _auth = auth;
            Title = "Sign In";
        }

        [RelayCommand]
        private async Task LoginAsync()
        {
            var email = Email?.Trim() ?? string.Empty;
            var password = Password?.Trim() ?? string.Empty;

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                SetError("Please enter both email and password.");
                return;
            }

            IsBusy = true;
            ClearError();

            try
            {
                var (success, message) = await _auth.LoginAsync(email, password);

                if (success)
                    await Shell.Current.GoToAsync("//home");
                else
                    SetError(message);
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        private async Task GoToRegisterAsync()
        {
            await Shell.Current.GoToAsync("register");
        }
    }
}
