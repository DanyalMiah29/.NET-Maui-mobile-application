using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RecipeVault.Interfaces;
using RecipeVault.Models;
using System.Collections.ObjectModel;

namespace RecipeVault.ViewModels
{
    [QueryProperty(nameof(Recipe), "Recipe")]
    public partial class RecipeDetailViewModel : BaseViewModel
    {
        private readonly ILocalDatabaseService _localDb;
        private readonly IAuthService          _auth;
        private readonly IFirestoreService     _firestore;

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(HasRecipe))]
        private Recipe? _recipe;

        [ObservableProperty] private bool _isFavorite;
        [ObservableProperty] private ObservableCollection<Ingredient> _ingredients = new();
        [ObservableProperty] private ObservableCollection<string> _mealTypes = new() { "Breakfast", "Lunch", "Dinner" };
        [ObservableProperty] private string _selectedMealType = "Dinner";
        [ObservableProperty] private DateTime _selectedDate   = DateTime.Today;

        public bool HasRecipe => Recipe is not null;

        public RecipeDetailViewModel(ILocalDatabaseService localDb, IAuthService auth, IFirestoreService firestore)
        {
            _localDb   = localDb;
            _auth      = auth;
            _firestore = firestore;
            Title      = "Recipe Detail";
        }

        partial void OnRecipeChanged(Recipe? value)
        {
            if (value is null) return;
            Title       = value.Name;
            Ingredients = new ObservableCollection<Ingredient>(value.Ingredients);
            _ = CheckFavoriteAsync();
        }

        private async Task CheckFavoriteAsync()
        {
            if (Recipe is null) return;
            await _localDb.InitAsync();
            IsFavorite = await _localDb.IsRecipeFavoriteAsync(Recipe.MealDbId);
        }

        [RelayCommand]
        private async Task ToggleFavoriteAsync()
        {
            if (Recipe is null) return;

            await _localDb.InitAsync();

            if (!IsFavorite)
            {
                Recipe.IsFavorite = true;
                await _localDb.SaveRecipeAsync(Recipe);
            }
            else
            {
                await _localDb.ToggleFavoriteAsync(Recipe.MealDbId);
            }

            IsFavorite = !IsFavorite;
        }

        [RelayCommand]
        private async Task AddToMealPlanAsync()
        {
            if (Recipe is null || !_auth.IsLoggedIn)
            {
                SetError("Please log in to add meals to your plan.");
                return;
            }

            IsBusy = true;
            ClearError();
            try
            {
                var entry = new MealPlanEntry
                {
                    UserId          = _auth.CurrentUser!.UserId,
                    Date            = SelectedDate,
                    MealType        = SelectedMealType,
                    RecipeName      = Recipe.Name,
                    RecipeThumbnail = Recipe.ThumbnailUrl,
                    MealDbId        = Recipe.MealDbId
                };

                await _localDb.InitAsync();

                // Save locally
                await _localDb.SaveMealPlanEntryAsync(entry);

                // Sync to Firestore cloud
                var docId = await _firestore.AddMealPlanEntryAsync(entry, _auth.CurrentUser.IdToken);
                if (!string.IsNullOrEmpty(docId))
                {
                    entry.FirestoreDocId = docId;
                    await _localDb.SaveMealPlanEntryAsync(entry);
                }

                await Shell.Current.DisplayAlert("Added!", $"{Recipe.Name} added to {SelectedMealType} on {SelectedDate:MMM dd}.", "OK");
            }
            catch (Exception ex)
            {
                SetError($"Could not add to meal plan: {ex.Message}");
            }
            finally { IsBusy = false; }
        }

        [RelayCommand]
        private async Task GoBackAsync() => await Shell.Current.GoToAsync("..");
    }
}
